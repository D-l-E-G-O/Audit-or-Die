Pour installer le jeu, veuillez suivre ces étapes :
	- Décompresser "Windows.zip"
	- Double-clic sur "AuditOrDie.msi"
	- L'exécutable "AuditOrDie.exe" est installé dans ProgramFiles/AuditOrDie
