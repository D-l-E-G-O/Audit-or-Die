Pour installer le jeu, veuillez suivre ces étapes :
	- Décompresser "Windows.zip"
	- Double-clic sur "AuditOrDie_installer.msi"
	- Choisissez l'emplacement d'installation
	- L'exécutable "AuditOrDie.exe" est installé et près à être utilisé
