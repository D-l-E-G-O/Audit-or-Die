Pour installer le jeu, veuillez suivre ces étapes :
	- Décompressez "Linux.zip":
		unzip Linux.zip
	- Rendez l'exécutable exécutable :
		chmod +x build/AuditOrDie.x86_64
	- Lancez le jeu :
		./build/AuditOrDie.x86_64
